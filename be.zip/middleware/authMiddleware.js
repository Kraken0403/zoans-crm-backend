const jwt = require('jsonwebtoken');

// Middleware to authenticate user
const authenticateJWT = (req, res, next) => {
    // const authHeader = req.headers['authorization'];
    // const token = authHeader?.split(' ')[1]; // Extract the token

    // if (!token) {
    //     req.user = null;
    //     return res.status(401).json({ error: 'Access denied. No token provided.' });
    // }

    // // Verify the token
    // jwt.verify(token, process.env.JWT_SECRET, (err, decoded) => {
    //     if (err) {
    //         req.user = null;
    //         return res.status(401).json({ error: 'Invalid token.' });
    //     }
    //     req.user = decoded; // Attach user data from token to req.user
    //     next();
    // });
    next();
};

module.exports = authenticateJWT;
