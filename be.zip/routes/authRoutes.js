const express = require('express');
const authController = require('../controllers/authController');
const authenticateJWT = require('../middleware/authMiddleware'); // Import the middleware
const router = express.Router();

// Public routes
router.post('/signup', authController.signup);
router.post('/login', authController.login);
router.post('/forgot-password', authController.forgotPassword);
router.post('/reset-password', authController.resetPassword);

// Protected routes
router.get('/dashboard', authenticateJWT, (req, res) => {
    res.json({ message: 'Welcome to the dashboard!', user: req.user }); // Access user info from req.user
});

module.exports = router;
