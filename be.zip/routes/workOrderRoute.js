const express = require('express');
const router = express.Router();
const workOrderController = require('../controllers/workOrderController');
const authenticateJWT = require('../middleware/authMiddleware');

router.use(authenticateJWT);

router.get('/work-orders', workOrderController.getWorkOrders);
router.get('/work-orders/:id', workOrderController.getWorkOrderById);
router.post('/work-orders', workOrderController.saveWorkOrder);
router.put('/work-orders/:id', workOrderController.updateWorkOrderStatus);

module.exports = router;