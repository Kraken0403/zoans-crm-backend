const express = require('express');
const router = express.Router();
const meetingController = require('../controllers/meetingController');

// Create a new meeting
router.post('/', meetingController.createMeeting);

// Get all meetings for a specific lead
router.get('/:leadId', meetingController.getMeetingsByLead);

// Delete a meeting
router.delete('/:id', meetingController.deleteMeeting);

module.exports = router;
