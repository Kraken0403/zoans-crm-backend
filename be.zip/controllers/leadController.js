const db = require('../config/db');
const { addOrUpdateCustomFields, getCustomFieldsByLeadId } = require('./customFieldValues');

// Helper function to normalize the follow_up_date
const normalizeDate = (date) => {
    if (!date) return null; // Handle null dates
    const parsedDate = new Date(date);
    return isNaN(parsedDate) ? null : parsedDate.toISOString().slice(0, 10); // Format to `YYYY-MM-DD`
};

// Create a new lead with custom fields
exports.createLead = (req, res) => {
    const {
        first_name,
        last_name,
        company_name,
        lead_status,
        email,
        phone_number,
        contact_name,
        follow_up_date,
        priority,
        assigned_salesperson,
        hotness,
        amount,
        notes,
        custom_fields,
    } = req.body;

    const created_by = req.user?.username || 'None';
    const normalizedFollowUpDate = normalizeDate(follow_up_date);

    db.beginTransaction((err) => {
        if (err) return res.status(500).json({ error: 'Transaction initialization failed', details: err.message });

        const leadQuery = `
            INSERT INTO leads (first_name, last_name, company_name, lead_status, email, phone_number, contact_name, follow_up_date, priority, assigned_salesperson, hotness, amount, notes, created_by)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `;
        const leadValues = [
            first_name, last_name, company_name, lead_status, email, phone_number, contact_name,
            normalizedFollowUpDate, priority, assigned_salesperson, hotness, amount, notes, created_by,
        ];

        db.query(leadQuery, leadValues, (err, result) => {
            if (err) return db.rollback(() => res.status(500).json({ error: 'Failed to create lead', details: err.message }));

            const leadId = result.insertId;

            // Add custom fields
            addOrUpdateCustomFields(leadId, custom_fields, res, (err) => {
                if (err) return db.rollback(() => res.status(500).json({ error: 'Failed to add custom fields', details: err.message }));

                db.commit((err) => {
                    if (err) return db.rollback(() => res.status(500).json({ error: 'Transaction commit failed', details: err.message }));
                    res.status(201).json({ message: 'Lead created successfully', leadId });
                });
            });
        });
    });
};

// Get all leads with their custom fields
exports.getAllLeads = (req, res) => {
    const leadsQuery = 'SELECT * FROM leads';
    const customFieldsQuery = 'SELECT * FROM lead_field_values WHERE lead_id IN (?)';

    db.query(leadsQuery, (err, leads) => {
        if (err) return res.status(500).json({ error: 'Failed to fetch leads', details: err.message });

        const leadIds = leads.map((lead) => lead.id);
        if (leadIds.length === 0) return res.status(200).json({ leads: [] });

        db.query(customFieldsQuery, [leadIds], (err, customFields) => {
            if (err) return res.status(500).json({ error: 'Failed to fetch custom fields', details: err.message });

            const leadsWithFields = leads.map((lead) => ({
                ...lead,
                custom_fields: customFields.filter((field) => field.lead_id === lead.id),
            }));

            res.status(200).json({ leads: leadsWithFields });
        });
    });
};

// Get a lead by ID along with its custom fields
exports.getLeadById = (req, res) => {
    const { id } = req.params;

    if (!id) {
        return res.status(400).json({ error: 'Lead ID is required' });
    }

    // Fetch the lead from the database
    const leadQuery = 'SELECT * FROM leads WHERE id = ?';
    db.query(leadQuery, [id], (err, leads) => {
        if (err) {
            return res.status(500).json({ error: 'Failed to fetch lead', details: err.message });
        }

        if (leads.length === 0) {
            return res.status(404).json({ message: 'Lead not found' });
        }

        const lead = leads[0];

        // Call getCustomFieldsByLeadId with a proper callback
        getCustomFieldsByLeadId(id, (err, customFields) => {
            if (err) {
                return res.status(500).json({ error: 'Failed to fetch custom fields', details: err.message });
            }

            lead.custom_fields = customFields;
            res.status(200).json(lead);
        });
    });
};
// Update a lead by ID along with custom fields
exports.updateLead = (req, res) => {
    const { id } = req.params;
    const {
        first_name,
        last_name,
        company_name,
        lead_status,
        email,
        phone_number,
        contact_name,
        follow_up_date,
        priority,
        assigned_salesperson,
        notes,
        amount,
        hotness,
        custom_fields,
    } = req.body;

    const normalizedFollowUpDate = normalizeDate(follow_up_date);

    const leadQuery = `
        UPDATE leads
        SET first_name = ?, last_name = ?, company_name = ?, lead_status = ?, email = ?, phone_number = ?, contact_name = ?, follow_up_date = ?, priority = ?, assigned_salesperson = ?, hotness = ?, amount = ?, notes = ?
        WHERE id = ?
    `;
    const leadValues = [
        first_name, last_name, company_name, lead_status, email, phone_number, contact_name,
        normalizedFollowUpDate, priority, assigned_salesperson, hotness, amount, notes, id,
    ];

    db.beginTransaction((err) => {
        if (err) {
            return res.status(500).json({ error: 'Transaction initialization failed', details: err.message });
        }

        // Update the lead details
        db.query(leadQuery, leadValues, (err) => {
            if (err) {
                return db.rollback(() => {
                    res.status(500).json({ error: 'Failed to update lead', details: err.message });
                });
            }

            // Add or update custom fields only if provided
            addOrUpdateCustomFields(id, custom_fields, res, (err) => {
                if (err) {
                    return db.rollback(() => {
                        res.status(500).json({ error: 'Failed to update custom fields', details: err.message });
                    });
                }

                // Commit the transaction if both lead and custom fields are updated successfully
                db.commit((err) => {
                    if (err) {
                        return db.rollback(() => {
                            res.status(500).json({ error: 'Transaction commit failed', details: err.message });
                        });
                    }

                    res.status(200).json({ message: 'Lead and custom fields updated successfully' });
                });
            });
        });
    });
};


// Delete a lead by ID
exports.deleteLead = (req, res) => {
    const { id } = req.params;

    db.beginTransaction((err) => {
        if (err) return res.status(500).json({ error: 'Transaction initialization failed', details: err.message });

        const deleteCustomFieldsQuery = 'DELETE FROM lead_field_values WHERE lead_id = ?';
        db.query(deleteCustomFieldsQuery, [id], (err) => {
            if (err) return db.rollback(() => res.status(500).json({ error: 'Failed to delete custom fields', details: err.message }));

            const deleteLeadQuery = 'DELETE FROM leads WHERE id = ?';
            db.query(deleteLeadQuery, [id], (err, result) => {
                if (err) return db.rollback(() => res.status(500).json({ error: 'Failed to delete lead', details: err.message }));

                if (result.affectedRows === 0) return db.rollback(() => res.status(404).json({ message: 'Lead not found' }));

                db.commit((err) => {
                    if (err) return db.rollback(() => res.status(500).json({ error: 'Transaction commit failed', details: err.message }));

                    res.status(200).json({ message: 'Lead and related custom fields deleted successfully' });
                });
            });
        });
    });
};
