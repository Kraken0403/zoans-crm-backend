const db = require('../config/db'); // Import your database connection

exports.getWorkOrderFields = (req, res) => {
    const query = `
        SELECT COLUMN_NAME 
        FROM INFORMATION_SCHEMA.COLUMNS 
        WHERE TABLE_NAME = 'work_orders' 
          AND TABLE_SCHEMA = DATABASE();
    `;

    db.query(query, (err, results) => {
        if (err) {
            console.error('Error fetching work order fields:', err);
            return res.status(500).json({ error: 'Failed to fetch work order fields.', details: err.message });
        }

        const fieldNames = results.map((field) => field.COLUMN_NAME);
        res.status(200).json({ fields: fieldNames });
    });
};

exports.getWorkOrderById = (req, res) => {
    const { id } = req.params;
    const query = 'SELECT * FROM work_orders WHERE WorkOrderID = ?';

    db.query(query, [id], (err, results) => {
        if (err) {
            console.error('Error fetching work order by ID:', err);
            return res.status(500).json({ error: 'Failed to fetch work order.', details: err.message });
        }

        if (results.length === 0) {
            return res.status(404).json({ message: 'Work order not found.' });
        }

        res.status(200).json({ workOrder: results[0] });
    });
};

exports.saveWorkOrder = (req, res) => {
    const { siteName, customerName, date, customerGST } = req.body;

    // Check if all fields are provided
    if (!siteName || !customerName || !date || !customerGST) {
        return res.status(400).json({ error: 'All fields are required.' });
    }

    // SQL query to insert a new work order
    const query = `
    INSERT INTO work_orders (SiteName, CustomerName, Date, CustomerGST) 
    VALUES (?, ?, ?, ?);
`;

    db.query(query, [siteName, customerName, date, customerGST], (err, result) => {
        if (err) {
            console.error('Error saving work order:', err);
            return res.status(500).json({ error: 'Error saving work order.', details: err.message });
        }

        res.status(200).json(result.insertId);
    });

};

exports.updateWorkOrderStatus = (req, res) => {
    const { id } = req.params; // Get WorkOrderID from URL
    const { status } = req.body; // Get new status from request body

    // Check if status is provided
    if (!status) {
        return res.status(400).json({ error: "Status field is required." });
    }

    // SQL query to update status
    const query = `
        UPDATE work_orders
        SET Status = ?
        WHERE WorkOrderID = ?;
    `;

    db.query(query, [status, id], (err, result) => {
        if (err) {
            console.error("Error updating work order status:", err);
            return res.status(500).json({ error: "Error updating work order status.", details: err.message });
        }

        // if (result.affectedRows === 0) {
        //     return res.status(404).json({ error: "Work order not found." });
        // }

        res.status(200).json({ message: "Work order status updated successfully." });
    });
};

exports.getWorkOrders = (req, res) => {
    const query = `
        SELECT WorkOrderID, SiteName, CustomerName, Date, CustomerGST, Status 
        FROM work_orders;
    `;

    db.query(query, (err, results) => {
        if (err) {
            console.error('Error fetching work orders:', err);
            return res.status(500).json({ error: 'Error fetching work orders.', details: err.message });
        }

        res.status(200).json({ workOrders: results });
    });
};