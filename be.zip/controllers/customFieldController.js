const db = require('../config/db'); // Import your database connection

// Create a new custom field
exports.createCustomField = (req, res) => {
    const { field_name, field_type, is_required, options, created_by } = req.body;

    // Logging the received data
    console.log('Received Data:', req.body);

    if (!field_name || !field_type) {
        return res.status(400).json({ error: 'Field name and type are required' });
    }

    db.beginTransaction((err) => {
        if (err) {
            console.log('Transaction failed:', err);
            return res.status(500).json({ error: 'Transaction failed' });
        }

        // Insert into lead_custom_fields table
        const fieldQuery = `
            INSERT INTO lead_custom_fields (field_name, field_type, is_required, created_by)
            VALUES (?, ?, ?, ?)
        `;
        db.query(fieldQuery, [field_name, field_type, is_required || false, created_by || null], (err, result) => {
            if (err) {
                console.log('Failed to insert into lead_custom_fields:', err);
                return db.rollback(() => res.status(500).json({ error: 'Failed to create custom field' }));
            }

            const fieldId = result.insertId;
            console.log('Inserted Field ID:', fieldId);

            // Insert options if provided
            if (options && options.length > 0) {
                const optionsQuery = `
                    INSERT INTO lead_custom_fields_option (field_id, option_value)
                    VALUES ?
                `;
                const optionValues = options.map(option => [fieldId, option]);

                db.query(optionsQuery, [optionValues], (err) => {
                    if (err) {
                        console.log('Failed to insert custom field options:', err);
                        return db.rollback(() => res.status(500).json({ error: 'Failed to add custom field options' }));
                    }

                    db.commit((err) => {
                        if (err) {
                            console.log('Transaction commit failed:', err);
                            return db.rollback(() => res.status(500).json({ error: 'Transaction commit failed' }));
                        }
                        res.status(201).json({ message: 'Custom field created successfully', field_id: fieldId });
                    });
                });
            } else {
                db.commit((err) => {
                    if (err) {
                        console.log('Transaction commit failed:', err);
                        return db.rollback(() => res.status(500).json({ error: 'Transaction commit failed' }));
                    }
                    res.status(201).json({ message: 'Custom field created successfully', field_id: fieldId });
                });
            }
        });
    });
};
// Get all custom fields with options
exports.getAllCustomFields = (req, res) => {
    const query = `
        SELECT cf.field_id, cf.field_name, cf.field_type, cf.is_required, cfo.option_value
        FROM lead_custom_fields cf
        LEFT JOIN lead_custom_fields_option cfo ON cf.field_id = cfo.field_id
    `;

    db.query(query, (err, results) => {
        if (err) return res.status(500).json({ error: 'Failed to fetch custom fields' });

        // Group options by field_id
        const fields = results.reduce((acc, row) => {
            const { field_id, field_name, field_type, is_required, option_value } = row;

            if (!acc[field_id]) {
                acc[field_id] = { field_id, field_name, field_type, is_required, options: [] };
            }

            if (option_value) acc[field_id].options.push(option_value);

            return acc;
        }, {});

        res.status(200).json(Object.values(fields));
    });
};

// Update a custom field
exports.updateCustomField = (req, res) => {
    const { field_id } = req.params;
    const { field_name, field_type, is_required, options } = req.body;

    const fieldQuery = `
        UPDATE lead_custom_fields
        SET field_name = ?, field_type = ?, is_required = ?
        WHERE field_id = ?
    `;

    db.beginTransaction((err) => {
        if (err) return res.status(500).json({ error: 'Transaction failed' });

        db.query(fieldQuery, [field_name, field_type, is_required, field_id], (err) => {
            if (err) {
                return db.rollback(() => res.status(500).json({ error: 'Failed to update custom field' }));
            }

            // Delete existing options
            const deleteOptionsQuery = `
                DELETE FROM lead_custom_fields_option WHERE field_id = ?
            `;
            db.query(deleteOptionsQuery, [field_id], (err) => {
                if (err) {
                    return db.rollback(() => res.status(500).json({ error: 'Failed to update field options' }));
                }

                // Insert new options
                if (options && options.length > 0) {
                    const optionsQuery = `
                        INSERT INTO lead_custom_fields_option (field_id, option_value)
                        VALUES ?
                    `;
                    const optionValues = options.map(option => [field_id, option]);

                    db.query(optionsQuery, [optionValues], (err) => {
                        if (err) {
                            return db.rollback(() => res.status(500).json({ error: 'Failed to add new field options' }));
                        }
                        db.commit((err) => {
                            if (err) {
                                return db.rollback(() => res.status(500).json({ error: 'Transaction commit failed' }));
                            }
                            res.status(200).json({ message: 'Custom field updated successfully' });
                        });
                    });
                } else {
                    db.commit((err) => {
                        if (err) {
                            return db.rollback(() => res.status(500).json({ error: 'Transaction commit failed' }));
                        }
                        res.status(200).json({ message: 'Custom field updated successfully' });
                    });
                }
            });
        });
    });
};

// Delete a custom field
exports.deleteCustomField = (req, res) => {
    const { field_id } = req.params;

    const deleteQuery = `
        DELETE FROM lead_custom_fields WHERE field_id = ?
    `;

    db.query(deleteQuery, [field_id], (err, result) => {
        if (err) return res.status(500).json({ error: 'Failed to delete custom field' });

        res.status(200).json({ message: 'Custom field deleted successfully' });
    });
};
