const db = require('../config/db'); // Import your database connection

exports.getLeadFields = (req, res) => {
    const query = `
        SELECT COLUMN_NAME 
        FROM INFORMATION_SCHEMA.COLUMNS 
        WHERE TABLE_NAME = 'leads' 
          AND TABLE_SCHEMA = DATABASE();
    `;

    db.query(query, (err, results) => {
        if (err) {
            console.error('Error fetching lead fields:', err);
            return res.status(500).json({ error: 'Failed to fetch lead fields.', details: err.message });
        }

        const fieldNames = results.map((field) => field.COLUMN_NAME);
        res.status(200).json({ fields: fieldNames });
    });
};

exports.saveFieldOrder = (req, res) => {
    const { fields } = req.body; // Expecting an array of field names from the frontend

    // Check if fields are provided
    if (!fields || fields.length === 0) {
        return res.status(400).json({ error: 'No fields provided.' });
    }

    // Ensure the user is authenticated
    if (!req.user) {
        return res.status(401).json({ error: 'User not authenticated.' });
    }

    const userId = req.user.id; // Extract user ID from the token

    // SQL query to save or update field order
    const query = `
        INSERT INTO field_order (user_id, fields) 
        VALUES (?, ?)
        ON DUPLICATE KEY UPDATE fields = ?;
    `;
    const fieldsJson = JSON.stringify(fields); // Convert the array to a JSON string

    // Execute the query
    db.query(query, [userId, fieldsJson, fieldsJson], (err, result) => {
        if (err) {
            console.error('Error saving field order:', err);
            return res.status(500).json({ error: 'Error saving field order.', details: err.message });
        }

        res.status(200).json({ message: 'Field order saved successfully.' });
    });
};

exports.getFieldOrder = (req, res) => {
    if (!req.user) {
        return res.status(401).json({ error: 'User not authenticated.' });
    }

    const userId = req.user.id;

    const query = `
        SELECT fields FROM field_order WHERE user_id = ?;
    `;

    db.query(query, [userId], (err, result) => {
        if (err) {
            console.error('Error fetching field order:', err);
            return res.status(500).json({ error: 'Error fetching field order.', details: err.message });
        }

        if (result.length === 0) {
            return res.status(404).json({ error: 'No field order found for this user.' });
        }

        // Since fields is already an array, no need to parse it
        const fieldOrder = result[0].fields; 
        res.status(200).json({ fieldOrder });
    });
};