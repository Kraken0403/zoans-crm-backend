const db = require('../config/db');

// Get custom fields for a specific lead

exports.getCustomFieldsByLeadId = (leadId, callback) => {
    if (!leadId) {
        return callback(new Error('Lead ID is required'), null);
    }

    const query = 'SELECT * FROM lead_field_values WHERE lead_id = ?';
    db.query(query, [leadId], (err, results) => {
        if (err) {
            return callback(err, null);
        }
        callback(null, results); // Pass results in the callback
    });
};



// Add or update custom fields for a lead
exports.addOrUpdateCustomFields = (leadId, customFields, res, callback) => {
    if (!customFields || customFields.length === 0) return callback(); // Skip if no custom fields

    const insertQuery = `
        INSERT INTO lead_field_values (lead_id, field_id, field_value)
        VALUES ?
        ON DUPLICATE KEY UPDATE field_value = VALUES(field_value)
    `;

    // Prepare the values to insert
    const values = customFields.map((field) => [leadId, field.field_id, field.field_value]);

    // Execute the query
    db.query(insertQuery, [values], (err) => {
        if (err) {
            // If an error occurs, respond with an error message
            console.error(err); // Log the error for debugging
            return res.status(500).json({ error: 'Failed to add or update custom fields', details: err.message });
        }
        // If successful, proceed with the callback
        callback();
    });
};