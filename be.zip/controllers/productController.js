const db = require('../config/db');

const getAllProducts = (req, res) => {
    const query = `
        SELECT 
            p.id AS productId, 
            p.name, 
            p.description, 
            p.cost, 
            p.stock, 
            p.category_id,
            p.type,
            p.sku,
            p.is_active,
            p.created_at,
            v.id AS variantId,
            v.sku AS variantSku,
            v.price,
            v.stock AS variantStock
        FROM products p
        LEFT JOIN variants v ON p.id = v.product_id
    `;

    db.query(query, (err, products) => {
        if (err) {
            return res.status(500).json({
                error: 'Failed to fetch products',
                details: err.message
            });
        }

        res.status(200).json(products);
    });
};



const createProduct = (req, res) => {
    const {
      name,
      category_id = 1,
      description = '',
      cost = 0,
      stock = 0,
      sku = '',
      type = 'simple',
      is_active = 1,
      variants = [] // Each should be { stock, sku, price, packaging: { weight, unit, length, width, height, dimension_unit }, attribute_option_ids: [] }
    } = req.body;
  
    if (!name) {
      return res.status(400).json({ error: 'Product name is required' });
    }
  
    const insertProductQuery = `
      INSERT INTO products (name, category_id, description, cost, stock, sku, type, is_active)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `;
  
    db.query(
      insertProductQuery,
      [name, category_id, description, cost, stock, sku, type, is_active],
      (err, result) => {
        if (err) {
          return res.status(500).json({ error: 'Failed to create product', details: err.message });
        }
  
        const productId = result.insertId;
  
        if (type === 'variable' && Array.isArray(variants) && variants.length > 0) {
          const variantValues = variants.map(v => [productId, v.stock || 0, v.sku || '', v.price || 0]);
          const insertVariantsQuery = `
            INSERT INTO variants (product_id, stock, sku, price)
            VALUES ?
          `;
  
          db.query(insertVariantsQuery, [variantValues], (err2, variantResult) => {
            if (err2) {
              return res.status(500).json({ error: 'Product created, but failed to insert variants', details: err2.message });
            }
  
            const variantInsertIds = Array.from({ length: variants.length }, (_, i) => variantResult.insertId + i);
  
            const variantAttributeValues = [];
            const packagingInserts = [];
  
            variants.forEach((variant, index) => {
              const variantId = variantInsertIds[index];
  
              // Attributes
              if (Array.isArray(variant.attribute_option_ids)) {
                variant.attribute_option_ids.forEach(attrOptId => {
                  variantAttributeValues.push([variantId, attrOptId]);
                });
              }
  
              // Packaging (per variant)
              if (variant.packaging && typeof variant.packaging === 'object') {
                const {
                  weight = null,
                  unit = null,
                  length = null,
                  width = null,
                  height = null,
                  dimension_unit = null
                } = variant.packaging;
  
                packagingInserts.push([
                  productId,
                  variantId,
                  variant.packaging.packaging_type || 'Box',
                  weight,
                  unit,
                  length,
                  width,
                  height,
                  dimension_unit
                ]);
              }
            });
  
            const insertPackaging = () => {
              if (packagingInserts.length === 0) return insertAttributes();
              const packagingQuery = `
                INSERT INTO product_packaging 
                (product_id, variant_id, packaging_type, packaging_weight, packaging_unit, length, width, height, dimensions_unit)
                VALUES ?
              `;
              db.query(packagingQuery, [packagingInserts], (err3) => {
                if (err3) {
                  return res.status(500).json({
                    error: 'Variants inserted, but failed to insert packaging',
                    details: err3.message
                  });
                }
                insertAttributes();
              });
            };
  
            const insertAttributes = () => {
              if (variantAttributeValues.length === 0) {
                return res.status(201).json({ message: 'Product and variants created', id: productId });
              }
              const attrValueQuery = `
                INSERT INTO variant_attribute_values (variant_id, attribute_option_id)
                VALUES ?
              `;
              db.query(attrValueQuery, [variantAttributeValues], (err4) => {
                if (err4) {
                  return res.status(500).json({
                    error: 'Variants created, but failed to insert attribute values',
                    details: err4.message
                  });
                }
                return res.status(201).json({ message: 'Product with variants and attributes created', id: productId });
              });
            };
  
            // Start with packaging insert
            insertPackaging();
          });
        } else {
          // If no variants (simple product)
          return res.status(201).json({ message: 'Product created successfully', id: productId });
        }
      }
    );
  };
  
  

const getProductById = (req, res) => {
    const query = 'SELECT * FROM products WHERE id = ?';
    db.query(query, [req.params.id], (err, result) => {
        if (err) return res.status(500).json({ error: 'Failed to fetch product', details: err.message });
        if (result.length === 0) return res.status(404).json({ message: 'Product not found' });
        res.status(200).json(result[0]);
    });
};

const updateProduct = (req, res) => {
    const { id } = req.params;
    const { name, description, cost, stock, type, is_active } = req.body;

    const query = `
        UPDATE products 
        SET name = ?, description = ?, cost = ?, stock = ?, type = ?, is_active = ?
        WHERE id = ?
    `;

    db.query(query, [name, description, cost, stock, type, is_active, id], (err) => {
        if (err) return res.status(500).json({ error: 'Failed to update product', details: err.message });
        res.status(200).json({ message: 'Product updated successfully' });
    });
};

// -------------------- VARIANTS --------------------
const createVariant = (req, res) => {
    const { product_id, sku, price, stock } = req.body;

    if (!product_id || !sku || price === undefined || stock === undefined) {
        return res.status(400).json({ error: 'Missing required fields for variant' });
    }

    const query = `INSERT INTO variants (product_id, sku, price, stock) VALUES (?, ?, ?, ?)`;

    db.query(query, [product_id, sku, price, stock], (err, result) => {
        if (err) return res.status(500).json({ error: 'Failed to create variant', details: err.message });
        res.status(201).json({ message: 'Variant created successfully', variantId: result.insertId });
    });
};

const getVariantByProductId = (req, res) => {
    const query = 'SELECT * FROM variants WHERE product_id = ?';
    db.query(query, [req.params.id], (err, result) => {
        if (err) return res.status(500).json({ error: 'Failed to fetch variants', details: err.message });
        res.status(200).json(result);
    });
};

// -------------------- CATEGORIES --------------------
const createCategory = (req, res) => {
    const { category, parent_id } = req.body;

    if (!category) return res.status(400).json({ error: 'Missing required field: category' });

    const slug = category.toLowerCase().replace(/\s+/g, '-');
    const checkQuery = 'SELECT * FROM categories WHERE slug = ?';

    db.query(checkQuery, [slug], (err, results) => {
        if (err) return res.status(500).json({ error: 'Failed to check slug', details: err.message });
        if (results.length > 0) return res.status(409).json({ error: 'Slug already exists' });

        const createQuery = 'INSERT INTO categories (name, slug, parent_id) VALUES (?, ?, ?)';
        db.query(createQuery, [category, slug, parent_id || null], (err, result) => {
            if (err) return res.status(500).json({ error: 'Failed to create category', details: err.message });
            res.status(201).json({ message: 'Category created successfully', categoryId: result.insertId });
        });
    });
};

const getCategories = (req, res) => {
    const query = 'SELECT * FROM categories';

    db.query(query, (err, results) => {
        if (err) return res.status(500).json({ error: 'Failed to fetch categories', details: err.message });

        const categoriesMap = {};
        const rootCategories = [];

        results.forEach(category => {
            category.children = [];
            categoriesMap[category.id] = category;
        });

        results.forEach(category => {
            if (category.parent_id) {
                categoriesMap[category.parent_id]?.children.push(category);
            } else {
                rootCategories.push(category);
            }
        });

        res.status(200).json(rootCategories);
    });
};


const getCategoryById = (req, res) => {
    const query = 'SELECT * FROM categories WHERE id = ?';
    db.query(query, [req.params.id], (err, results) => {
        if (err) return res.status(500).json({ error: 'Failed to fetch category', details: err.message });
        if (results.length === 0) return res.status(404).json({ error: 'Category not found' });
        res.status(200).json(results[0]);
    });
};

const getCategoryByName = (req, res) => {
    const name = req.params.name;
    const query = 'SELECT * FROM categories WHERE name = ?';

    db.query(query, [name], (err, results) => {
        if (err) return res.status(500).json({ error: 'Failed to fetch category by name', details: err.message });
        if (results.length === 0) return res.status(404).json({ error: 'Category not found' });
        res.status(200).json(results[0]);
    });
};

const checkCategory = (req, res) => {
    const { name } = req.body;
    if (!name) return res.status(400).json({ error: 'Missing required field: name' });

    const slug = name.toLowerCase().replace(/\s+/g, '-');
    const query = 'SELECT * FROM categories WHERE slug = ?';

    db.query(query, [slug], (err, results) => {
        if (err) return res.status(500).json({ error: 'Failed to check category', details: err.message });

        res.status(200).json({ exists: results.length > 0 });
    });
};



// -------------------- ATTRIBUTES --------------------
const createAttribute = (req, res) => {
    const { name } = req.body;
    if (!name) return res.status(400).json({ error: 'Missing attribute name' });

    const query = `INSERT INTO attributes (name) VALUES (?)`;
    db.query(query, [name], (err, result) => {
        if (err) return res.status(500).json({ error: 'Failed to create attribute', details: err.message });
        res.status(201).json({ message: 'Attribute created', attributeId: result.insertId });
    });
};

const getAllAttributes = (req, res) => {
    const query = `SELECT * FROM attributes`;
    db.query(query, (err, results) => {
        if (err) return res.status(500).json({ error: 'Failed to fetch attributes', details: err.message });
        res.status(200).json(results);
    });
};

// -------------------- ATTRIBUTE OPTIONS --------------------
const createAttributeOption = (req, res) => {
    const { attribute_id, value } = req.body;
    if (!attribute_id || !value) return res.status(400).json({ error: 'Missing required fields' });

    const query = `INSERT INTO attribute_options (attribute_id, value) VALUES (?, ?)`;
    db.query(query, [attribute_id, value], (err, result) => {
        if (err) return res.status(500).json({ error: 'Failed to create attribute option', details: err.message });
        res.status(201).json({ message: 'Attribute option created', optionId: result.insertId });
    });
};

const getAttributeOptions = (req, res) => {
    const attributeId = req.params.id;
    const query = `SELECT * FROM attribute_options WHERE attribute_id = ?`;

    db.query(query, [attributeId], (err, results) => {
        if (err) return res.status(500).json({ error: 'Failed to fetch attribute options', details: err.message });
        res.status(200).json(results);
    });
};

// -------------------- VARIANT ATTRIBUTE VALUES --------------------
const addVariantAttributeValue = (req, res) => {
    const { variant_id, attribute_option_id } = req.body;

    if (!variant_id || !attribute_option_id) {
        return res.status(400).json({ error: 'Missing required fields' });
    }

    const query = `INSERT INTO variant_attribute_values (variant_id, attribute_option_id) VALUES (?, ?)`;
    db.query(query, [variant_id, attribute_option_id], (err, result) => {
        if (err) return res.status(500).json({ error: 'Failed to link attribute to variant', details: err.message });
        res.status(201).json({ message: 'Attribute option added to variant' });
    });
};

const getAttributesForVariant = (req, res) => {
    const variantId = req.params.id;

    const query = `
        SELECT a.name AS attribute, ao.value AS optionValue
        FROM variant_attribute_values vav
        JOIN attribute_options ao ON vav.attribute_option_id = ao.id
        JOIN attributes a ON ao.attribute_id = a.id
        WHERE vav.variant_id = ?
    `;

    db.query(query, [variantId], (err, results) => {
        if (err) return res.status(500).json({ error: 'Failed to fetch variant attributes', details: err.message });
        res.status(200).json(results);
    });
};

// -------------------- CATEGORY HANDLING --------------------


// -------------------- VARIANT MANAGEMENT --------------------
const createVariantWithAttributes = (req, res) => {
    const { product_id, stock, sku, price, attribute_option_ids } = req.body;

    if (!product_id || !sku || !price || !Array.isArray(attribute_option_ids) || attribute_option_ids.length === 0) {
        return res.status(400).json({ error: 'Required fields missing' });
    }

    // Step 1: Ensure product is of type "variable"
    const productTypeQuery = 'SELECT type FROM products WHERE id = ?';
    db.query(productTypeQuery, [product_id], (err, results) => {
        if (err) return res.status(500).json({ error: 'Database error', details: err.message });

        if (results.length === 0) {
            return res.status(404).json({ error: 'Product not found' });
        }

        if (results[0].type !== 'variable') {
            return res.status(400).json({ error: 'Cannot create variants for a simple product' });
        }

        // ✅ Continue to create the variant...
        const insertVariantQuery = `
            INSERT INTO variants (product_id, stock, sku, price)
            VALUES (?, ?, ?, ?)
        `;

        db.query(insertVariantQuery, [product_id, stock, sku, price], (err2, result) => {
            if (err2) return res.status(500).json({ error: 'Failed to create variant', details: err2.message });

            const variantId = result.insertId;

            // Map attributes to variant
            const variantAttrValues = attribute_option_ids.map(id => [variantId, id]);
            const variantAttrQuery = `INSERT INTO variant_attribute_options (variant_id, attribute_option_id) VALUES ?`;

            db.query(variantAttrQuery, [variantAttrValues], (err3) => {
                if (err3) return res.status(500).json({ error: 'Failed to link attributes', details: err3.message });

                res.status(201).json({ message: 'Variant created successfully', variantId });
            });
        });
    });
};


const getVariantsByProduct = (req, res) => {
    const productId = req.params.productId;
    const query = `
        SELECT v.*, 
               GROUP_CONCAT(ao.value SEPARATOR ', ') AS attribute_values
        FROM variants v
        LEFT JOIN variant_attribute_values vav ON v.id = vav.variant_id
        LEFT JOIN attribute_options ao ON vav.attribute_option_id = ao.id
        WHERE v.product_id = ?
        GROUP BY v.id
    `;

    db.query(query, [productId], (err, results) => {
        if (err) return res.status(500).json({ error: 'Failed to fetch variants', details: err.message });
        res.status(200).json(results);
    });
};

// -------------------- ASSIGN ATTRIBUTE TO PRODUCT --------------------
const assignAttributeToProduct = (req, res) => {
    const { attribute_option_ids } = req.body;
    const { productId } = req.params;

    if (!Array.isArray(attribute_option_ids) || attribute_option_ids.length === 0) {
        return res.status(400).json({ error: 'Attribute Option IDs must be a non-empty array' });
    }

    const values = attribute_option_ids.map(id => [productId, id]);
    const query = `INSERT INTO product_attribute_options (product_id, attribute_option_id) VALUES ?`;

    db.query(query, [values], (err) => {
        if (err) {
            return res.status(500).json({ error: 'Failed to assign attributes to product', details: err.message });
        }

        res.status(201).json({ message: 'Attributes assigned successfully' });
    });
};


// -------------------- PACKAGING --------------------

// Create a new packaging type (if needed elsewhere)
const addPackaging = (req, res) => {
    const { name } = req.body;
    if (!name) return res.status(400).json({ error: 'Packaging name is required' });

    const query = `INSERT INTO packagings (name) VALUES (?)`;
    db.query(query, [name], (err, result) => {
        if (err) return res.status(500).json({ error: 'Failed to add packaging', details: err.message });
        res.status(201).json({ message: 'Packaging created', packagingId: result.insertId });
    });
};

// 🔹 Add packaging for a simple product
const addProductPackaging = (req, res) => {
    const productId = req.params.productId;
    const {
        packagingType,
        packagingWeight,
        packagingUnit,
        length,
        width,
        height,
        dimensionsUnit
    } = req.body;

    const checkQuery = 'SELECT id FROM product_packaging WHERE product_id = ?';
    db.query(checkQuery, [productId], (err, existing) => {
        if (err) return res.status(500).json({ error: 'Error checking existing packaging', details: err.message });

        if (existing.length > 0) {
            return res.status(400).json({ error: 'Packaging already exists for this product.' });
        }

        const insertQuery = `
            INSERT INTO product_packaging 
            (product_id, packaging_type, packaging_weight, packaging_unit, length, width, height, dimensions_unit)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        `;
        db.query(insertQuery, [
            productId, packagingType, packagingWeight, packagingUnit,
            length, width, height, dimensionsUnit
        ], (err2) => {
            if (err2) return res.status(500).json({ error: 'Failed to add packaging', details: err2.message });
            res.status(201).json({ message: 'Packaging added successfully.' });
        });
    });
};


// 🔹 Get packaging for a simple product
const getProductPackaging = (req, res) => {
    const productId = req.params.productId;

    const query = `
        SELECT id, packaging_type, packaging_weight, packaging_unit,
               length, width, height, dimensions_unit
        FROM product_packaging
        WHERE product_id = ?
    `;
    db.query(query, [productId], (err, results) => {
        if (err) return res.status(500).json({ error: 'Failed to fetch packaging', details: err.message });
        res.status(200).json(results);
    });
};


// 🔹 Add packaging for a variant
const addVariantPackaging = (req, res) => {
    const variantId = req.params.variantId;
    const {
        packagingType,
        packagingWeight,
        packagingUnit,
        length,
        width,
        height,
        dimensionsUnit
    } = req.body;

    const checkQuery = 'SELECT id FROM product_packaging WHERE variant_id = ?';
    db.query(checkQuery, [variantId], (err, existing) => {
        if (err) return res.status(500).json({ error: 'Error checking existing packaging', details: err.message });

        if (existing.length > 0) {
            return res.status(400).json({ error: 'Packaging already exists for this variant.' });
        }

        const insertQuery = `
            INSERT INTO product_packaging 
            (variant_id, packaging_type, packaging_weight, packaging_unit, length, width, height, dimensions_unit)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        `;
        db.query(insertQuery, [
            variantId, packagingType, packagingWeight, packagingUnit,
            length, width, height, dimensionsUnit
        ], (err2) => {
            if (err2) return res.status(500).json({ error: 'Failed to add packaging', details: err2.message });
            res.status(201).json({ message: 'Packaging added successfully.' });
        });
    });
};


const removeProductPackaging = (req, res) => {
    const productId = req.params.productId;

    const deleteQuery = 'DELETE FROM product_packagings WHERE product_id = ?';
    db.query(deleteQuery, [productId], (err, result) => {
        if (err) return res.status(500).json({ error: 'Failed to delete packaging', details: err.message });

        if (result.affectedRows === 0) {
            return res.status(404).json({ error: 'No packaging found for this product.' });
        }

        res.json({ message: 'Packaging removed successfully.' });
    });
};

const removeVariantPackaging = (req, res) => {
    const variantId = req.params.variantId;

    const deleteQuery = 'DELETE FROM variant_packagings WHERE variant_id = ?';
    db.query(deleteQuery, [variantId], (err, result) => {
        if (err) return res.status(500).json({ error: 'Failed to delete packaging', details: err.message });

        if (result.affectedRows === 0) {
            return res.status(404).json({ error: 'No packaging found for this variant.' });
        }

        res.json({ message: 'Packaging removed successfully.' });
    });
};




// 🔹 Get packaging for a variant
const getVariantPackaging = (req, res) => {
    const variantId = req.params.variantId;

    const query = `
        SELECT id, packaging_type, packaging_weight, packaging_unit,
               length, width, height, dimensions_unit
        FROM product_packaging
        WHERE variant_id = ?
    `;
    db.query(query, [variantId], (err, results) => {
        if (err) return res.status(500).json({ error: 'Failed to fetch packaging', details: err.message });
        res.status(200).json(results);
    });
};

module.exports = {
    // Products
    getAllProducts,
    createProduct,
    getProductById,
    updateProduct,

    // Variants
    createVariant,
    getVariantByProductId,

    // Categories
    createCategory,

    // Attributes
    createAttribute,
    getAllAttributes,

    // Attribute Options
    createAttributeOption,
    getAttributeOptions,

    // Variant Attribute Mapping
    addVariantAttributeValue,

    getAttributesForVariant,
     // Woo-style category
     getCategories,
     getCategoryById,
     getCategoryByName,
     checkCategory,
 
     // Woo-style attribute mapping
     assignAttributeToProduct,
 
     // Variant with attributes
     createVariantWithAttributes,
     getVariantsByProduct,

    //  Packaging

    addPackaging,
    addProductPackaging,
    getProductPackaging,
    addVariantPackaging,
    getVariantPackaging,

    removeProductPackaging,
    removeVariantPackaging
};
